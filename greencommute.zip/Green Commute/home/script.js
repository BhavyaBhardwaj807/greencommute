// Toggle the navigation menu when the menu icon is clicked
function toggleNav() {
    const nav = document.getElementById("side-nav");
    if (nav.style.display === "block") {
        nav.style.display = "none";
    } else {
        nav.style.display = "block";
    }
}
