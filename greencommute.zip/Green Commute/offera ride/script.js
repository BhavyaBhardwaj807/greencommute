// JavaScript to handle image change on button click
document.getElementById('find-companion-btn').addEventListener('click', function () {
    const rideImage = document.getElementById('ride-image');
    rideImage.src = '2.png'; // Replace with the path to Picture 2
});
